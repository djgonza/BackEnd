<?php 
	include "config/config.php";
	$controlador = new Controlador();
	$controlador ->run();
?>

