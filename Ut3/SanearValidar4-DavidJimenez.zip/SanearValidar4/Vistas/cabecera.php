<!DOCTYPE html>
	<html lang="es">
	<head>
		<title>Formulario</title>
		<meta chasert="UTF-8" />
		<link rel="stylesheet" type="text/css" href="css/style.css" />
	</head>
	<body>
		<h1>Formulario - Datos Alumno</h1>