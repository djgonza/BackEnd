﻿<?php

include 'cabecera.php';

echo $resultado;

include 'pie.php';
?>
