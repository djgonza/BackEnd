
--
-- Estructura de tabla para la tabla `cursillosTusIniciales`
--

CREATE TABLE IF NOT EXISTS `cursilloska` (
  `CODCUR` varchar(2) NOT NULL,
  `NOMCUR` varchar(25) NOT NULL,
  `NUMHORAS` int(11) NOT NULL,
  `FECHA` date NOT NULL,
  `CODP` varchar(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `cursillos`
--

INSERT INTO `cursilloska` (`CODCUR`, `NOMCUR`, `NUMHORAS`, `FECHA`, `CODP`) VALUES
('C1', 'YOGA', 30, '2016-08-01', 'P1'),
('C2', 'STRETCHING', 40, '2016-08-02', 'P1'),
('C3', 'PATINAJE', 30, '2016-07-16', 'P2'),
('C4', 'TIRO CON ARCO', 20, '2016-08-01', 'P3'),
('C5', 'RAPSBERRY PI', 20, '2016-08-05', 'P4'),
('C6', 'PATINAJE', 35, '2016-11-12', 'P2'),
('C7', 'FOTOGRAFIA', 50, '2016-11-12', 'P4');
