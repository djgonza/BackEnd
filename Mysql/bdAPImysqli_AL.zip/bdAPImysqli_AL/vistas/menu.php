 <div id="menu">
                <ul>
                    <li><a href="?"><strong>Inicio</strong></a></li>
                    <li><a href="?opcion=listar"><strong>Listar</strong></a></li>
                     <li><a href="#">Insertar</a></li>
                     <li><a href="#">Borrar</a></li>
                     <li><a href="#">Modificar</a></li>
                     <li><a href="#">Buscar</a></li>
                    
                </ul>
</div> <!-- fin de menú  -->   
