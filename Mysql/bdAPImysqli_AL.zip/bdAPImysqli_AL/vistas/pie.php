    </div>     <!-- fin de principal-->
    <div id="pie">
            <p class="copyright">
                &copy; <?php echo date("Y"); ?> Bases de datos y PHP
            </p>
     </div>
    </div><!-- fin de contenido -->
    </body>
</html>
