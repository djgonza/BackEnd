<!DOCTYPE html>
<html>
    <!-- La cabecera del documento -->
    <head>
        <title>Ejercicios</title>
        <meta charset="UTF-8" />
        <link rel="stylesheet" type="text/css" href="css/estilo.css" />

    </head>

    <!-- el cuerpo  -->
    <body>
    <div id="contenido">
        <div id="cabecera">
            <h1> PHP y Bases de datos - BD Personas</h1>
            <?php include "menu.php" ?>
        </div> <!-- fin de cabecera -->
        <div id="principal">