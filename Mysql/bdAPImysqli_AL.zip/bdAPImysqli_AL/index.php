<?php
//El código del controlador
?>